from distutils.core import setup, Extension

setup(name='company',
version='1.0',
classifiers = [ 'company'],
packages=['company'],
)
